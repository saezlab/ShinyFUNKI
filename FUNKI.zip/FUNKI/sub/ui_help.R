tabPanel(
  title = "Help",
  includeMarkdown("inst/helppage.md")
)