## Contact Us
This App was firstly implemented by Christian Holland, and it is currently developed and maintained by Rosa Hernansaiz-Ballesteros at the <a href="http://saezlab.org" target="_blank">Saezlab</a>, Institute for Computational Biomedicine, University of Heidelberg.

Please do not hesitate to [contact](mailto: rosa.hernansaiz@uni-heidelberg.de) us for feedback, questions or suggestions. If you have questions of potential interest for other users please use the <a href="https://github.com/saezlab/ShinyFUNKI/issues" target="_blank">GitHub Issue</a> system.
